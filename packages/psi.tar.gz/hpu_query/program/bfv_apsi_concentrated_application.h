#ifndef HPU_PROGRAM_BFV_APSI_CONCENTRATED_APPLICATION_H
#define HPU_PROGRAM_BFV_APSI_CONCENTRATED_APPLICATION_H

#include <stddef.h>
#include <stdint.h>

#ifndef HPU_DMA_SPAN_T_DEFINED
#define HPU_DMA_SPAN_T_DEFINED
typedef struct hpu_dma_span {
    uint32_t line_offset;
    uint32_t line_count;
} hpu_dma_span_t;
#endif

#ifdef __cplusplus
extern "C" {
#endif

enum { HPU_PROGRAM_BFV_APSI_CONCENTRATED_APPLICATION_DMA_COUNT = 1161 };
int hpu_program_bfv_apsi_concentrated_application(const hpu_dma_span_t *spans, size_t span_count);

int hpu_run_bfv_apsi_concentrated_application(void);

#ifdef __cplusplus
}
#endif

#endif
