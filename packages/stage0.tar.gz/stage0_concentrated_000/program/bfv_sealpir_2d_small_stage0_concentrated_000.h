#ifndef HPU_PROGRAM_BFV_SEALPIR_2D_SMALL_STAGE0_CONCENTRATED_000_H
#define HPU_PROGRAM_BFV_SEALPIR_2D_SMALL_STAGE0_CONCENTRATED_000_H

#include <stddef.h>
#include <stdint.h>

#ifndef HPU_DMA_SPAN_T_DEFINED
#define HPU_DMA_SPAN_T_DEFINED
typedef struct hpu_dma_span {
    uint32_t line_offset;
    uint32_t line_count;
} hpu_dma_span_t;
#endif

#ifdef __cplusplus
extern "C" {
#endif

enum { HPU_PROGRAM_BFV_SEALPIR_2D_SMALL_STAGE0_CONCENTRATED_000_DMA_COUNT = 6434 };
int hpu_program_bfv_sealpir_2d_small_stage0_concentrated_000(const hpu_dma_span_t *spans, size_t span_count);

int hpu_run_bfv_sealpir_2d_small_stage0_concentrated_000(void);

#ifdef __cplusplus
}
#endif

#endif
